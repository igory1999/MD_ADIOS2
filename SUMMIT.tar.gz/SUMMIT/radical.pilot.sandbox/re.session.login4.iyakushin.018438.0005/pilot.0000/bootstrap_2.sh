#!/bin/sh

# disable user site packages as those can conflict with our virtualenv
export PYTHONNOUSERSITE=True

# make sure we use the correct sandbox
cd /gpfs/alpine/scratch/iyakushin/csc299/radical.pilot.sandbox/re.session.login4.iyakushin.018438.0005/pilot.0000

# apply some env settings as stored after running pre_bootstrap_0 commands
export PATH="/sw/sources/lsf-tools/2.0/summit/bin:/sw/summit/ums/ompix/gcc/8.1.1/install/prrte-dev-withtimings/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-setuptools-40.4.3-xynpmbuwujfkcw52tegkndot6jj5bye5/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-virtualenv-16.0.0-ohsvxc5mf4aornhyrfp4ecea5bzcowon/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-pip-10.0.1-ppmoqmblkncxkfwytkqpu4afmqylywbj/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/python-3.7.0-ei3mpdncii74xsn55t5kxpuc46i3oezn/bin:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-8.1.1/zeromq-4.2.5-7rfblal2q7klw76ot57stcrasifjddzo/bin:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-8.1.1/libfabric-1.7.0-xkjxkthk7r5rheyhoapeygtoe23pqh7w/bin:/sw/summit/gcc/8.1.1/bin:/usr/bin:/usr/sbin:/opt/ibm/csm/bin:/opt/ibm/spectrumcomputing/lsf/10.1.0.9/linux3.10-glibc2.17-ppc64le-csm/bin:/ccs/home/iyakushin/.conda/envs/T20/bin:/sw/summit/python/3.7/anaconda3/5.3.0/condabin:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/darshan-runtime-3.1.7-cnvxicgf5j4ap64qi6v5gxp67hmrjz43/bin:/sw/sources/hpss/bin:/opt/ibm/spectrumcomputing/lsf/10.1.0.9/linux3.10-glibc2.17-ppc64le-csm/etc:/usr/local/bin:/usr/local/sbin:/opt/ibm/flightlog/bin:/opt/ibutils/bin:/opt/ibm/spectrum_mpi/jsm_pmix/bin:/opt/puppetlabs/bin:/usr/lpp/mmfs/bin"
export LD_LIBRARY_PATH="/sw/summit/ums/ompix/gcc/8.1.1/install/prrte-dev-withtimings/lib:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-setuptools-40.4.3-xynpmbuwujfkcw52tegkndot6jj5bye5/lib:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-virtualenv-16.0.0-ohsvxc5mf4aornhyrfp4ecea5bzcowon/lib:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-pip-10.0.1-ppmoqmblkncxkfwytkqpu4afmqylywbj/lib:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/python-3.7.0-ei3mpdncii74xsn55t5kxpuc46i3oezn/lib:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-8.1.1/zeromq-4.2.5-7rfblal2q7klw76ot57stcrasifjddzo/lib:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-8.1.1/libfabric-1.7.0-xkjxkthk7r5rheyhoapeygtoe23pqh7w/lib:/sw/summit/gcc/8.1.1/lib64:/opt/ibm/spectrumcomputing/lsf/10.1.0.9/linux3.10-glibc2.17-ppc64le-csm/lib:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/darshan-runtime-3.1.7-cnvxicgf5j4ap64qi6v5gxp67hmrjz43/lib:/opt/ibm/spectrum_mpi/jsm_pmix/lib"

# activate virtenv
if test "default" = "anaconda" && test -e "/ccs/home/iyakushin/.conda/envs/T20/bin/conda"
then
    conda activate /gpfs/alpine/csc299/scratch/iyakushin/radical.pilot.sandbox/ve.ornl.summit.1.4.1
else
    . /gpfs/alpine/csc299/scratch/iyakushin/radical.pilot.sandbox/ve.ornl.summit.1.4.1/bin/activate
fi

# make sure rp_install is used
export PYTHONPATH=/gpfs/alpine/scratch/iyakushin/csc299/radical.pilot.sandbox/re.session.login4.iyakushin.018438.0005/pilot.0000/rp_install/lib/python3.7/site-packages::/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-setuptools-40.4.3-xynpmbuwujfkcw52tegkndot6jj5bye5/lib/python3.7/site-packages:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-virtualenv-16.0.0-ohsvxc5mf4aornhyrfp4ecea5bzcowon/lib/python2.7/site-packages:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-pip-10.0.1-ppmoqmblkncxkfwytkqpu4afmqylywbj/lib/python3.7/site-packages
export PATH=/gpfs/alpine/scratch/iyakushin/csc299/radical.pilot.sandbox/re.session.login4.iyakushin.018438.0005/pilot.0000/rp_install/bin:/gpfs/alpine/csc299/scratch/iyakushin/radical.pilot.sandbox/ve.ornl.summit.1.4.1/bin:/gpfs/alpine/csc299/scratch/iyakushin/radical.pilot.sandbox/ve.ornl.summit.1.4.1/bin:/sw/sources/lsf-tools/2.0/summit/bin:/sw/summit/ums/ompix/gcc/8.1.1/install/prrte-dev-withtimings/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-setuptools-40.4.3-xynpmbuwujfkcw52tegkndot6jj5bye5/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-virtualenv-16.0.0-ohsvxc5mf4aornhyrfp4ecea5bzcowon/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-pip-10.0.1-ppmoqmblkncxkfwytkqpu4afmqylywbj/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/python-3.7.0-ei3mpdncii74xsn55t5kxpuc46i3oezn/bin:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-8.1.1/zeromq-4.2.5-7rfblal2q7klw76ot57stcrasifjddzo/bin:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-8.1.1/libfabric-1.7.0-xkjxkthk7r5rheyhoapeygtoe23pqh7w/bin:/sw/summit/gcc/8.1.1/bin:/usr/bin:/usr/sbin:/opt/ibm/csm/bin:/opt/ibm/spectrumcomputing/lsf/10.1.0.9/linux3.10-glibc2.17-ppc64le-csm/bin:/ccs/home/iyakushin/.conda/envs/T20/bin:/sw/summit/python/3.7/anaconda3/5.3.0/condabin:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/darshan-runtime-3.1.7-cnvxicgf5j4ap64qi6v5gxp67hmrjz43/bin:/sw/sources/hpss/bin:/opt/ibm/spectrumcomputing/lsf/10.1.0.9/linux3.10-glibc2.17-ppc64le-csm/etc:/usr/local/bin:/usr/local/sbin:/opt/ibm/flightlog/bin:/opt/ibutils/bin:/opt/ibm/spectrum_mpi/jsm_pmix/bin:/opt/puppetlabs/bin:/usr/lpp/mmfs/bin

# run agent in debug mode
# FIXME: make option again?
export RADICAL_VERBOSE=DEBUG
export RADICAL_UTIL_VERBOSE=DEBUG
export RADICAL_PILOT_VERBOSE=DEBUG

# the agent will *always* use the dburl from the config file, not from the env
# FIXME: can we better define preference in the session ctor?
unset RADICAL_PILOT_DBURL

# avoid ntphost lookups on compute nodes
export RADICAL_PILOT_NTPHOST=46.101.140.169

# pass environment variables down so that module load becomes effective at
# the other side too (e.g. sub-agents).

module unload xl
module unload xalt
module unload spectrum-mpi
module load gcc/8.1.1
module load zeromq/4.2.5
module load python/3.7.0
module load py-pip/10.0.1-py3
module load py-virtualenv/16.0.0
module load py-setuptools/40.4.3-py3
module use /sw/summit/ums/ompix/gcc/8.1.1/modules
module load prrte/1.0.0_devtiming
export PRRTE_PREFIX=/sw/summit/ums/ompix/gcc/8.1.1/install/prrte-dev-withtimings
ulimit -u 65536

# start agent, forward arguments
# NOTE: exec only makes sense in the last line of the script
exec /gpfs/alpine/csc299/scratch/iyakushin/radical.pilot.sandbox/ve.ornl.summit.1.4.1/bin/python /gpfs/alpine/scratch/iyakushin/csc299/radical.pilot.sandbox/re.session.login4.iyakushin.018438.0005/pilot.0000/rp_install/bin/radical-pilot-agent "$1" 1>"$1.out" 2>"$1.err"

