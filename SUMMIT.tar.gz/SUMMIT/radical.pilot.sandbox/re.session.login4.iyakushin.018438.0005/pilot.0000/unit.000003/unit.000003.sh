#!/bin/sh


# Environment variables
export RP_SESSION_ID="re.session.login4.iyakushin.018438.0005"
export RP_PILOT_ID="pilot.0000"
export RP_AGENT_ID="agent.0"
export RP_SPAWNER_ID="agent_executing.0000"
export RP_UNIT_ID="unit.000003"
export RP_UNIT_NAME="task.0000, 0_0 ,stage.0000,0,pipeline.0000,0"
export RP_GTOD="/gpfs/alpine/csc299/scratch/iyakushin/radical.pilot.sandbox/re.session.login4.iyakushin.018438.0005/pilot.0000/gtod"
export RP_TMP="None"
export RP_PILOT_SANDBOX="/gpfs/alpine/csc299/scratch/iyakushin/radical.pilot.sandbox/re.session.login4.iyakushin.018438.0005/pilot.0000"
export RP_PILOT_STAGING="/gpfs/alpine/csc299/scratch/iyakushin/radical.pilot.sandbox/re.session.login4.iyakushin.018438.0005/pilot.0000/staging_area"
export RP_PROF="/gpfs/alpine/scratch/iyakushin/csc299/radical.pilot.sandbox/re.session.login4.iyakushin.018438.0005/pilot.0000/unit.000003//unit.000003.prof"

prof(){
    if test -z "$RP_PROF"
    then
        return
    fi
    event=$1
    msg=$2
    now=$($RP_GTOD)
    echo "$now,$event,unit_script,MainThread,$RP_UNIT_ID,AGENT_EXECUTING,$msg" >> $RP_PROF
}
export OMP_NUM_THREADS="1"
export "CUDA_VISIBLE_DEVICES="

prof cu_start

# Change to unit sandbox
cd /gpfs/alpine/scratch/iyakushin/csc299/radical.pilot.sandbox/re.session.login4.iyakushin.018438.0005/pilot.0000/unit.000003/
prof cu_cd_done

# The command to run
prof cu_exec_start
/opt/ibm/spectrum_mpi/jsm_pmix/bin/jsrun --erf_input /gpfs/alpine/scratch/iyakushin/csc299/radical.pilot.sandbox/re.session.login4.iyakushin.018438.0005/pilot.0000/unit.000003//unit.000003.rs   /ccs/home/iyakushin/.conda/envs/T20/bin/python "/gpfs/alpine/csc299/proj-shared/iyakushin/MD_ADIOS2/simulation.py" "/gpfs/alpine/csc299/proj-shared/iyakushin/MD_ADIOS2/run_1/simulations/all/0_0" "/gpfs/alpine/csc299/proj-shared/iyakushin/MD_ADIOS2/adios.xml" 
RETVAL=$?
prof cu_exec_stop

# Exit the script with the return code from the command
prof cu_stop
exit $RETVAL
