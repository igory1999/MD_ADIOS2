#!/bin/sh

# disable user site packages as those can conflict with our virtualenv
export PYTHONNOUSERSITE=True

# make sure we use the correct sandbox
cd /home/igor/radical.pilot.sandbox/re.session.pr7530.igor.018438.0008/pilot.0000

# apply some env settings as stored after running pre_bootstrap_0 commands
export PATH="/home/igor/bin:/home/igor/cuda11_samples/NVIDIA_CUDA-11.0_Samples/bin/x86_64/linux/release:/usr/local/bin:/usr/local/go/bin:/home/igor/bin:/home/igor/.conda/envs/MD_ADIOS/bin:/usr/local/Anaconda3-2020.02/condabin:/usr/local/Anaconda3-2020.02/bin:/home/igor/SOFTWARE/INSTALL/gcc/7.5.0/adios2-2.5.0/bin:/home/igor/cuda11_samples/NVIDIA_CUDA-11.0_Samples/bin/x86_64/linux/release:/usr/local/bin:/usr/local/go/bin:/home/igor/bin:/home/igor/spack/bin:/home/igor/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/home/igor/go/bin:/home/igor/go/bin"
export LD_LIBRARY_PATH="/home/igor/SOFTWARE/INSTALL/gcc/7.5.0/adios2-2.5.0/lib"

# activate virtenv
if test "default" = "anaconda" && test -e "/home/igor/.conda/envs/MD_ADIOS/bin/conda"
then
    conda activate /home/igor/radical.pilot.sandbox/ve.local.localhost.1.4.0
else
    . /home/igor/radical.pilot.sandbox/ve.local.localhost.1.4.0/bin/activate
fi

# make sure rp_install is used
export PYTHONPATH=/home/igor/radical.pilot.sandbox/re.session.pr7530.igor.018438.0008/pilot.0000/rp_install/lib/python3.7/site-packages::/home/igor/SOFTWARE/INSTALL/gcc/7.5.0/adios2-2.5.0/lib/python3.7/site-packages
export PATH=/home/igor/radical.pilot.sandbox/re.session.pr7530.igor.018438.0008/pilot.0000/rp_install/bin:/home/igor/radical.pilot.sandbox/ve.local.localhost.1.4.0/bin:/home/igor/radical.pilot.sandbox/ve.local.localhost.1.4.0/bin:/home/igor/bin:/home/igor/cuda11_samples/NVIDIA_CUDA-11.0_Samples/bin/x86_64/linux/release:/usr/local/bin:/usr/local/go/bin:/home/igor/bin:/home/igor/.conda/envs/MD_ADIOS/bin:/usr/local/Anaconda3-2020.02/condabin:/usr/local/Anaconda3-2020.02/bin:/home/igor/SOFTWARE/INSTALL/gcc/7.5.0/adios2-2.5.0/bin:/home/igor/cuda11_samples/NVIDIA_CUDA-11.0_Samples/bin/x86_64/linux/release:/usr/local/bin:/usr/local/go/bin:/home/igor/bin:/home/igor/spack/bin:/home/igor/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/home/igor/go/bin:/home/igor/go/bin

# run agent in debug mode
# FIXME: make option again?
export RADICAL_VERBOSE=DEBUG
export RADICAL_UTIL_VERBOSE=DEBUG
export RADICAL_PILOT_VERBOSE=DEBUG

# the agent will *always* use the dburl from the config file, not from the env
# FIXME: can we better define preference in the session ctor?
unset RADICAL_PILOT_DBURL

# avoid ntphost lookups on compute nodes
export RADICAL_PILOT_NTPHOST=46.101.140.169

# pass environment variables down so that module load becomes effective at
# the other side too (e.g. sub-agents).

export RP_APP_TUNNEL_ADDR=144.76.72.175:27017
echo

# start agent, forward arguments
# NOTE: exec only makes sense in the last line of the script
exec /home/igor/radical.pilot.sandbox/ve.local.localhost.1.4.0/bin/python /home/igor/radical.pilot.sandbox/re.session.pr7530.igor.018438.0008/pilot.0000/rp_install/bin/radical-pilot-agent "$1" 1>"$1.out" 2>"$1.err"

