#!/bin/sh


# Environment variables
export RP_SESSION_ID="re.session.pr7530.igor.018438.0008"
export RP_PILOT_ID="pilot.0000"
export RP_AGENT_ID="agent.0"
export RP_SPAWNER_ID="agent_executing.0000"
export RP_UNIT_ID="unit.000007"
export RP_UNIT_NAME="task.0017, 3_1 ,stage.0007,1,pipeline.0003,3"
export RP_GTOD="/home/igor/radical.pilot.sandbox/re.session.pr7530.igor.018438.0008/pilot.0000/gtod"
export RP_TMP="None"
export RP_PILOT_SANDBOX="/home/igor/radical.pilot.sandbox/re.session.pr7530.igor.018438.0008/pilot.0000"
export RP_PILOT_STAGING="/home/igor/radical.pilot.sandbox/re.session.pr7530.igor.018438.0008/pilot.0000/staging_area"
export RP_PROF="/home/igor/radical.pilot.sandbox/re.session.pr7530.igor.018438.0008/pilot.0000/unit.000007//unit.000007.prof"

prof(){
    if test -z "$RP_PROF"
    then
        return
    fi
    event=$1
    msg=$2
    now=$($RP_GTOD)
    echo "$now,$event,unit_script,MainThread,$RP_UNIT_ID,AGENT_EXECUTING,$msg" >> $RP_PROF
}
export OMP_NUM_THREADS="1"
export "CUDA_VISIBLE_DEVICES="

prof cu_start

# Change to unit sandbox
cd /home/igor/radical.pilot.sandbox/re.session.pr7530.igor.018438.0008/pilot.0000/unit.000007/
prof cu_cd_done

# The command to run
prof cu_exec_start
/home/igor/.conda/envs/MD_ADIOS/bin/python "/home/igor/Development/MD_ADIOS2/simulation.py" "/home/igor/Development/MD_ADIOS2/run_1/simulations/all/3_1" "/home/igor/Development/MD_ADIOS2/adios.xml" 
RETVAL=$?
prof cu_exec_stop

# Exit the script with the return code from the command
prof cu_stop
exit $RETVAL
